import Header from '../components/Header';
import Footer from '../components/Footer';
import { Users, Target, Award, Heart } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-sky-400 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            আমাদের সম্পর্কে
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            আমরা একটি বিশ্বস্ত ইন্টারনেট সেবা প্রদানকারী প্রতিষ্ঠান যা গ্রাহক সন্তুষ্টিকে সর্বোচ্চ অগ্রাধিকার দেয়।
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <Target className="h-12 w-12 text-blue-600 mb-6" />
              <h2 className="text-2xl font-bold text-gray-800 mb-4">আমাদের লক্ষ্য</h2>
              <p className="text-gray-600 leading-relaxed">
                আমাদের লক্ষ্য হলো বাংলাদেশের প্রতিটি ঘরে ঘরে উচ্চমানের ইন্টারনেট সেবা পৌঁছে দেওয়া। 
                আমরা চাই প্রতিটি মানুষ ডিজিটাল বিশ্বের সাথে সহজে সংযুক্ত হতে পারুক এবং 
                তথ্য প্রযুক্তির সুবিধা নিতে পারুক।
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg">
              <Heart className="h-12 w-12 text-green-600 mb-6" />
              <h2 className="text-2xl font-bold text-gray-800 mb-4">আমাদের দৃষ্টিভঙ্গি</h2>
              <p className="text-gray-600 leading-relaxed">
                আমাদের দৃষ্টিভঙ্গি হলো একটি সংযুক্ত বাংলাদেশ গড়া যেখানে প্রযুক্তি মানুষের 
                জীবনযাত্রার মান উন্নয়নে ভূমিকা রাখবে। আমরা বিশ্বাস করি যে সহজ ও সাশ্রয়ী 
                ইন্টারনেট সেবার মাধ্যমে দেশের উন্নয়নে অবদান রাখতে পারি।
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              আমাদের মূল্যবোধ
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              আমাদের কাজের প্রতিটি ক্ষেত্রে এই মূল্যবোধগুলো আমাদের পথপ্রদর্শক।
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <Users className="h-16 w-16 text-blue-600 mx-auto mb-6" />
              <h3 className="text-xl font-semibold text-gray-800 mb-4">গ্রাহক সেবা</h3>
              <p className="text-gray-600">
                গ্রাহকদের সন্তুষ্টিই আমাদের প্রধান লক্ষ্য। আমরা সর্বদা গ্রাহকদের 
                প্রয়োজনকে অগ্রাধিকার দিয়ে কাজ করি।
              </p>
            </div>

            <div className="text-center p-6">
              <Award className="h-16 w-16 text-green-600 mx-auto mb-6" />
              <h3 className="text-xl font-semibold text-gray-800 mb-4">গুণগত মান</h3>
              <p className="text-gray-600">
                আমরা কখনো মানের সাথে আপস করি না। প্রতিটি সেবায় আমরা সর্বোচ্চ 
                মানের নিশ্চয়তা প্রদান করি।
              </p>
            </div>

            <div className="text-center p-6">
              <Heart className="h-16 w-16 text-red-600 mx-auto mb-6" />
              <h3 className="text-xl font-semibold text-gray-800 mb-4">আন্তরিকতা</h3>
              <p className="text-gray-600">
                আমরা আন্তরিকতার সাথে প্রতিটি গ্রাহকের সেবা করি এবং তাদের সাথে 
                দীর্ঘমেয়াদী সম্পর্ক গড়ে তুলি।
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="bg-gray-100 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              আমাদের টিম
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              আমাদের রয়েছে অভিজ্ঞ ও দক্ষ পেশাদারদের একটি টিম যারা আপনার সেবায় নিয়োজিত।
            </p>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-lg text-center max-w-4xl mx-auto">
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              আমাদের টিম গঠিত হয়েছে নেটওয়ার্ক ইঞ্জিনিয়ার, কাস্টমার সাপোর্ট স্পেশালিস্ট, 
              এবং প্রযুক্তি বিশেষজ্ঞদের নিয়ে। আমরা সবাই মিলে কাজ করি যাতে আপনি পান 
              সেরা ইন্টারনেট অভিজ্ঞতা।
            </p>
            <p className="text-lg text-gray-600">
              আমাদের প্রতিটি সদস্য গ্রাহক সন্তুষ্টির জন্য প্রতিশ্রুতিবদ্ধ এবং সর্বদা 
              নতুন প্রযুক্তি ও পদ্ধতি শিখতে আগ্রহী।
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;
