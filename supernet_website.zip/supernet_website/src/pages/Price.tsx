import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { Check, Wifi, Users, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

const Price = () => {
  const packages = [
    {
      name: "বেসিক স্টার্টার",
      speed: "৫ এমবিপিএস",
      price: "৫০০",
      features: [
        "২৪/৭ বেসিক সাপোর্ট",
        "ফ্রি রাউটার",
        "আনলিমিটেড ডাউনলোড",
        "৬ মাস ওয়ারেন্টি",
        "বেসিক নেটওয়ার্ক সিকিউরিটি"
      ],
      recommended: false,
      color: "blue"
    },
    {
      name: "হোম বেসিক",
      speed: "১০ এমবিপিএস",
      price: "৮০০",
      features: [
        "২৪/৭ কাস্টমার সাপোর্ট",
        "ফ্রি রাউটার",
        "আনলিমিটেড ডাউনলোড",
        "১ বছর ওয়ারেন্টি",
        "অ্যাডভান্সড সিকিউরিটি"
      ],
      recommended: false,
      color: "indigo"
    },
    {
      name: "হোম স্ট্যান্ডার্ড",
      speed: "২০ এমবিপিএস",
      price: "১২০০",
      features: [
        "২৪/৭ কাস্টমার সাপোর্ট",
        "ফ্রি রাউটার + ওয়াইফাই",
        "আনলিমিটেড ডাউনলোড",
        "২ বছর ওয়ারেন্টি",
        "প্রিমিয়াম সিকিউরিটি"
      ],
      recommended: true,
      color: "green"
    },
    {
      name: "হোম প্রিমিয়াম",
      speed: "৫০ এমবিপিএস",
      price: "২০০০",
      features: [
        "২৪/৭ প্রিমিয়াম সাপোর্ট",
        "ফ্রি ডুয়াল ব্যান্ড রাউটার",
        "আনলিমিটেড ডাউনলোড",
        "৩ বছর ওয়ারেন্টি",
        "এন্টারপ্রাইজ সিকিউরিটি"
      ],
      recommended: false,
      color: "purple"
    },
    {
      name: "অফিস বেসিক",
      speed: "৭৫ এমবিপিএস",
      price: "২৮০০",
      features: [
        "বিজনেস সাপোর্ট",
        "এন্টারপ্রাইজ রাউটার",
        "স্ট্যাটিক আইপি",
        "২ বছর ওয়ারেন্টি",
        "বিজনেস গ্রেড সিকিউরিটি"
      ],
      recommended: false,
      color: "orange"
    },
    {
      name: "অফিস স্ট্যান্ডার্ড",
      speed: "১০০ এমবিপিএস",
      price: "৩৫০০",
      features: [
        "ডেডিকেটেড সাপোর্ট টিম",
        "এন্টারপ্রাইজ রাউটার",
        "স্ট্যাটিক আইপি",
        "৩ বছর ওয়ারেন্টি",
        "অ্যাডভান্সড ফায়ারওয়াল"
      ],
      recommended: false,
      color: "red"
    },
    {
      name: "অফিস প্রো",
      speed: "১৫০ এমবিপিএস",
      price: "৫০০০",
      features: [
        "প্রিমিয়াম বিজনেস সাপোর্ট",
        "হাই-স্পিড রাউটার",
        "ডেডিকেটেড আইপি",
        "৫ বছর ওয়ারেন্টি",
        "ক্লাউড ব্যাকআপ সেবা"
      ],
      recommended: false,
      color: "teal"
    },
    {
      name: "এন্টারপ্রাইজ",
      speed: "২০০ এমবিপিএস",
      price: "৮০০০",
      features: [
        "২৪/৭ এন্টারপ্রাইজ সাপোর্ট",
        "প্রো-গ্রেড ইকুপমেন্ট",
        "মাল্টিপল আইপি",
        "লাইফটাইম সাপোর্ট",
        "ডেডিকেটেড নেটওয়ার্ক"
      ],
      recommended: false,
      color: "gray"
    },
    {
      name: "আল্ট্রা স্পিড",
      speed: "৩০০ এমবিপিএস",
      price: "১২০০০",
      features: [
        "প্রিমিয়াম টেকনিক্যাল সাপোর্ট",
        "আল্ট্রা হাই-স্পিড রাউটার",
        "ডেডিকেটেড বান্ডউইথ",
        "২৪/৭ নেটওয়ার্ক মনিটরিং",
        "অগ্রাধিকার ভিত্তিক সেবা"
      ],
      recommended: false,
      color: "cyan"
    },
    {
      name: "ম্যাক্স পারফরমেন্স",
      speed: "৫০০ এমবিপিএস",
      price: "১৮০০০",
      features: [
        "এক্সক্লুসিভ সাপোর্ট টিম",
        "কাস্টম নেটওয়ার্ক সলিউশন",
        "আনলিমিটেড স্ট্যাটিক আইপি",
        "জিরো ডাউনটাইম গ্যারান্টি",
        "কর্পোরেট গ্রেড ইনফ্রাস্ট্রাকচার"
      ],
      recommended: false,
      color: "violet"
    }
  ];

  const getColorClasses = (color: string, recommended: boolean) => {
    const colors = {
      blue: {
        bg: recommended ? 'bg-gradient-to-br from-blue-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-blue-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-blue-600',
        button: recommended 
          ? 'bg-white text-blue-600 hover:bg-gray-100' 
          : 'bg-blue-600 text-white hover:bg-blue-700'
      },
      indigo: {
        bg: recommended ? 'bg-gradient-to-br from-indigo-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-indigo-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-indigo-600',
        button: recommended 
          ? 'bg-white text-indigo-600 hover:bg-gray-100' 
          : 'bg-indigo-600 text-white hover:bg-indigo-700'
      },
      green: {
        bg: recommended ? 'bg-gradient-to-br from-blue-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-blue-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-blue-600',
        button: recommended 
          ? 'bg-white text-blue-600 hover:bg-gray-100' 
          : 'bg-green-600 text-white hover:bg-green-700'
      },
      purple: {
        bg: recommended ? 'bg-gradient-to-br from-purple-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-purple-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-purple-600',
        button: recommended 
          ? 'bg-white text-purple-600 hover:bg-gray-100' 
          : 'bg-purple-600 text-white hover:bg-purple-700'
      },
      orange: {
        bg: recommended ? 'bg-gradient-to-br from-orange-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-orange-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-orange-600',
        button: recommended 
          ? 'bg-white text-orange-600 hover:bg-gray-100' 
          : 'bg-orange-600 text-white hover:bg-orange-700'
      },
      red: {
        bg: recommended ? 'bg-gradient-to-br from-red-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-red-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-red-600',
        button: recommended 
          ? 'bg-white text-red-600 hover:bg-gray-100' 
          : 'bg-red-600 text-white hover:bg-red-700'
      },
      teal: {
        bg: recommended ? 'bg-gradient-to-br from-teal-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-teal-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-teal-600',
        button: recommended 
          ? 'bg-white text-teal-600 hover:bg-gray-100' 
          : 'bg-teal-600 text-white hover:bg-teal-700'
      },
      gray: {
        bg: recommended ? 'bg-gradient-to-br from-gray-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-gray-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-gray-600',
        button: recommended 
          ? 'bg-white text-gray-600 hover:bg-gray-100' 
          : 'bg-gray-600 text-white hover:bg-gray-700'
      },
      cyan: {
        bg: recommended ? 'bg-gradient-to-br from-cyan-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-cyan-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-cyan-600',
        button: recommended 
          ? 'bg-white text-cyan-600 hover:bg-gray-100' 
          : 'bg-cyan-600 text-white hover:bg-cyan-700'
      },
      violet: {
        bg: recommended ? 'bg-gradient-to-br from-violet-600 to-sky-400' : 'bg-white',
        border: recommended ? 'border-violet-600' : 'border-gray-200',
        text: recommended ? 'text-white' : 'text-gray-800',
        accent: 'text-violet-600',
        button: recommended 
          ? 'bg-white text-violet-600 hover:bg-gray-100' 
          : 'bg-violet-600 text-white hover:bg-violet-700'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-sky-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-sky-400 py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-10 left-10 w-20 h-20 bg-white opacity-10 rounded-full animate-pulse"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-yellow-300 opacity-20 rounded-full animate-bounce"></div>
          <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-300 opacity-15 rounded-full animate-pulse"></div>
        </div>
        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-8 animate-fade-in">
            দাম তালিকা
          </h1>
          <p className="text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed animate-fade-in">
            আপনার প্রয়োজন অনুযায়ী সেরা প্যাকেজ বেছে নিন। সব প্যাকেজেই পাবেন সর্বোচ্চ মানের সেবা।
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {packages.map((pkg, index) => {
              const colorClasses = getColorClasses(pkg.color, pkg.recommended);
              return (
                <div
                  key={index}
                  className={`relative rounded-2xl border-2 ${colorClasses.border} ${colorClasses.bg} p-8 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 ${
                    pkg.recommended ? 'scale-105 z-10' : ''
                  } animate-fade-in`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {pkg.recommended && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-gray-800 px-6 py-2 rounded-full text-sm font-bold shadow-lg animate-pulse">
                        সবচেয়ে জনপ্রিয়
                      </span>
                    </div>
                  )}

                  <div className="text-center mb-8">
                    <div className={`h-16 w-16 mx-auto mb-6 ${
                      pkg.recommended ? 'text-white' : colorClasses.accent
                    } flex items-center justify-center bg-white bg-opacity-20 rounded-2xl backdrop-blur-sm`}>
                      <Wifi className="h-8 w-8" />
                    </div>
                    <h3 className={`text-2xl font-bold ${colorClasses.text} mb-3`}>
                      {pkg.name}
                    </h3>
                    <div className={`text-4xl font-bold ${colorClasses.text} mb-2`}>
                      ৳{pkg.price}
                    </div>
                    <div className={`text-sm ${
                      pkg.recommended ? 'text-blue-100' : 'text-gray-500'
                    } mb-4`}>
                      প্রতি মাসে
                    </div>
                    <div className={`text-xl font-semibold ${
                      pkg.recommended ? 'text-blue-100' : colorClasses.accent
                    } bg-white bg-opacity-20 px-4 py-2 rounded-lg`}>
                      {pkg.speed}
                    </div>
                  </div>

                  <ul className="space-y-4 mb-8">
                    {pkg.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-3">
                        <Check className={`h-5 w-5 mt-0.5 ${
                          pkg.recommended ? 'text-green-200' : 'text-green-500'
                        } flex-shrink-0`} />
                        <span className={`text-sm ${
                          pkg.recommended ? 'text-blue-100' : 'text-gray-600'
                        }`}>
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>

                  <Link to="/contact" className="block">
                    <Button 
                      className={`w-full py-3 text-lg font-medium shadow-lg transition-all duration-300 transform hover:scale-105 ${colorClasses.button}`}
                    >
                      এই প্যাকেজ নিন
                    </Button>
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Additional Info */}
      <section className="bg-white py-24 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-20 left-20 w-40 h-40 bg-blue-500 rounded-full"></div>
          <div className="absolute bottom-20 right-20 w-32 h-32 bg-green-500 rounded-full"></div>
        </div>
        <div className="relative container mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              অতিরিক্ত সুবিধা
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              সব প্যাকেজের সাথে পাবেন এই বিশেষ সুবিধাগুলো
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-blue-100 rounded-3xl border-2 border-blue-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <Users className="h-16 w-16 text-blue-600 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">২৪/৭ সাপোর্ট</h3>
              <p className="text-gray-600 leading-relaxed">
                যেকোনো সমস্যায় আমাদের দক্ষ টিম আছে আপনার সেবায়।
              </p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-green-50 to-green-100 rounded-3xl border-2 border-green-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <Wifi className="h-16 w-16 text-green-600 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">নির্ভরযোগ্য সেবা</h3>
              <p className="text-gray-600 leading-relaxed">
                উন্নত প্রযুক্তি ও পেশাদার সেবা পাবেন সবসময়।
              </p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-purple-50 to-purple-100 rounded-3xl border-2 border-purple-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <Clock className="h-16 w-16 text-purple-600 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">কোন লুকানো চার্জ নেই</h3>
              <p className="text-gray-600 leading-relaxed">
                যা দেখছেন তাই দিতে হবে, কোনো অতিরিক্ত খরচ নেই।
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Price;
