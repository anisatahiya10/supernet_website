import { Link } from 'react-router-dom';
import { Wifi, Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Wifi className="h-8 w-8 text-blue-400" />
              <span className="text-xl font-bold">Supernet Online Service</span>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              সহজ সংযোগ, নিরবিচারে ভালোবাসা। আমরা আপনার বিশ্বস্ত ইন্টারনেট সেবা প্রদানকারী।
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">দ্রুত লিংক</h3>
            <div className="space-y-2">
              <Link to="/" className="block text-gray-300 hover:text-white transition-colors">
                হোম
              </Link>
              <Link to="/about" className="block text-gray-300 hover:text-white transition-colors">
                আমাদের সম্পর্কে
              </Link>
              <Link to="/price" className="block text-gray-300 hover:text-white transition-colors">
                দাম তালিকা
              </Link>
              <Link to="/contact" className="block text-gray-300 hover:text-white transition-colors">
                যোগাযোগ
              </Link>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">সেবাসমূহ</h3>
            <div className="space-y-2 text-gray-300">
              <p>হোম ইন্টারনেট</p>
              <p>অফিস ইন্টারনেট</p>
              <p>ওয়াইফাই সংযোগ</p>
              <p>২৪/৭ সাপোর্ট</p>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">যোগাযোগের তথ্য</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-blue-400" />
                <span className="text-gray-300">০১৭১২-৩৪৫৬৭৮</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-blue-400" />
                <span className="text-gray-300">info@dotinternet.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-blue-400" />
                <span className="text-gray-300">ঢাকা, বাংলাদেশ</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center">
          <p className="text-gray-400">
            © ২০২৪ Supernet Online Service। সকল অধিকার সংরক্ষিত।
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
