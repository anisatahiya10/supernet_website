import Header from '../components/Header';
import Footer from '../components/Footer';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

const Contact = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-sky-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 via-blue-700 to-sky-400 py-24 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-10 left-10 w-20 h-20 bg-white opacity-10 rounded-full animate-pulse"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-yellow-300 opacity-20 rounded-full animate-bounce"></div>
          <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-300 opacity-15 rounded-full animate-pulse"></div>
        </div>
        <div className="relative container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-8 animate-fade-in">
              যোগাযোগ
            </h1>
            <p className="text-2xl text-blue-100 max-w-3xl mx-auto leading-relaxed animate-fade-in">
              আমাদের সাথে যোগাযোগ করুন এবং পেয়ে যান সেরা ইন্টারনেট সেবা
            </p>
            <div className="mt-8 flex justify-center">
              <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-full px-8 py-3">
                <p className="text-white font-medium">যেকোনো সময় যোগাযোগ করুন</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 animate-fade-in">
              যোগাযোগের তথ্য
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              আমাদের সাথে সরাসরি যোগাযোগ করুন এবং পেয়ে যান দ্রুত সেবা
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Phone Contact */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-3xl border-2 border-blue-200 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-fade-in">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-8 shadow-lg">
                <Phone className="h-8 w-8" />
              </div>
              <h3 className="text-3xl font-bold text-blue-600 mb-6 text-center">ফোন</h3>
              <div className="space-y-4 text-center">
                <div className="bg-white p-4 rounded-2xl border-2 border-dashed border-blue-300 shadow-inner">
                  <p className="text-2xl font-mono font-bold text-gray-800 mb-2">০১৭১২-৩৪৫৬৭৮</p>
                  <p className="text-sm text-gray-500">(প্রধান নম্বর)</p>
                </div>
                <div className="bg-white p-4 rounded-2xl border-2 border-dashed border-blue-300 shadow-inner">
                  <p className="text-2xl font-mono font-bold text-gray-800 mb-2">০১৮৯৮-৭৬৫৪৩২</p>
                  <p className="text-sm text-gray-500">(বিকল্প নম্বর)</p>
                </div>
              </div>
            </div>

            {/* Email Contact */}
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-3xl border-2 border-green-200 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-8 shadow-lg">
                <Mail className="h-8 w-8" />
              </div>
              <h3 className="text-3xl font-bold text-green-600 mb-6 text-center">ইমেইল</h3>
              <div className="space-y-4 text-center">
                <div className="bg-white p-4 rounded-2xl border-2 border-dashed border-green-300 shadow-inner">
                  <p className="text-xl font-mono font-bold text-gray-800 mb-2">info@dotinternet-bd.com</p>
                  <p className="text-sm text-gray-500">(সাধারণ তথ্য)</p>
                </div>
                <div className="bg-white p-4 rounded-2xl border-2 border-dashed border-green-300 shadow-inner">
                  <p className="text-xl font-mono font-bold text-gray-800 mb-2">support@dotinternet-bd.com</p>
                  <p className="text-sm text-gray-500">(টেকনিক্যাল সাপোর্ট)</p>
                </div>
              </div>
            </div>

            {/* Office Address */}
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-3xl border-2 border-purple-200 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-8 shadow-lg">
                <MapPin className="h-8 w-8" />
              </div>
              <h3 className="text-3xl font-bold text-purple-600 mb-6 text-center">অফিস</h3>
              <div className="bg-white p-6 rounded-2xl border-2 border-dashed border-purple-300 shadow-inner text-center">
                <p className="text-lg font-semibold text-gray-800 mb-4">
                  ১২৩, কারওয়ান বাজার
                </p>
                <p className="text-lg font-semibold text-gray-800 mb-4">
                  ঢাকা-১২১৫, বাংলাদেশ
                </p>
                <p className="text-sm text-gray-500 bg-purple-50 px-4 py-2 rounded-lg">
                  প্রধান কার্যালয়
                </p>
              </div>
            </div>

            {/* Office Hours */}
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-8 rounded-3xl border-2 border-orange-200 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-fade-in" style={{ animationDelay: '0.6s' }}>
              <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-8 shadow-lg">
                <Clock className="h-8 w-8" />
              </div>
              <h3 className="text-3xl font-bold text-orange-600 mb-6 text-center">অফিস সময়</h3>
              <div className="bg-white p-6 rounded-2xl border-2 border-dashed border-orange-300 shadow-inner">
                <div className="space-y-3 text-center">
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <p className="font-semibold text-gray-800">রবিবার - বৃহস্পতিবার</p>
                    <p className="text-orange-600 font-bold">৯:০০ - ৬:০০</p>
                  </div>
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <p className="font-semibold text-gray-800">শুক্রবার</p>
                    <p className="text-orange-600 font-bold">৯:০০ - ৫:০০</p>
                  </div>
                  <div className="bg-red-50 p-3 rounded-lg border border-red-200">
                    <p className="font-semibold text-gray-800">শনিবার</p>
                    <p className="text-red-600 font-bold">বন্ধ</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Services Info */}
      <section className="bg-white py-24 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-20 left-20 w-40 h-40 bg-blue-500 rounded-full"></div>
          <div className="absolute bottom-20 right-20 w-32 h-32 bg-green-500 rounded-full"></div>
        </div>
        <div className="relative container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
              কেন আমাদের বেছে নেবেন?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              আমাদের সেবা নিয়ে জানুন এবং সেরা ইন্টারনেট অভিজ্ঞতা পান
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-blue-100 rounded-3xl border-2 border-blue-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-6">
                <Phone className="h-8 w-8" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">২৪/৭ সাপোর্ট</h3>
              <p className="text-gray-600 leading-relaxed">
                যেকোনো সমস্যায় আমাদের দক্ষ টিম আছে আপনার সেবায়।
              </p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-green-50 to-green-100 rounded-3xl border-2 border-green-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-6">
                <Mail className="h-8 w-8" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">দ্রুত সেবা</h3>
              <p className="text-gray-600 leading-relaxed">
                আপনার যোগাযোগের ২৪ ঘন্টার মধ্যে আমরা উত্তর দেব।
              </p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-purple-50 to-purple-100 rounded-3xl border-2 border-purple-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-6">
                <MapPin className="h-8 w-8" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">সহজ অবস্থান</h3>
              <p className="text-gray-600 leading-relaxed">
                ঢাকার কেন্দ্রস্থলে আমাদের অফিস, সহজেই খুঁজে পাবেন।
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;
