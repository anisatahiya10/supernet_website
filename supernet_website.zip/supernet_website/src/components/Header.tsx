import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Wifi } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50 border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 p-2 text-blue-600 hover:text-blue-800 transition-colors">
            <Wifi className="h-8 w-8" />
            <span className="text-xl font-bold">Supernet Online Service</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-1">
            <Link to="/" className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium">
              হোম
            </Link>
            <Link to="/about" className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium">
              আমাদের সম্পর্কে
            </Link>
            <Link to="/price" className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium">
              দাম তালিকা
            </Link>
            <Link to="/contact" className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium">
              যোগাযোগ
            </Link>
            <Link to="/pay-bill" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors font-medium">
              পে বিল
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden p-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-2">
              <Link
                to="/"
                className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                হোম
              </Link>
              <Link
                to="/about"
                className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                আমাদের সম্পর্কে
              </Link>
              <Link
                to="/price"
                className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                দাম তালিকা
              </Link>
              <Link
                to="/contact"
                className="px-4 py-2 text-gray-700 hover:text-blue-600 hover:bg-gray-100 rounded-md transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                যোগাযোগ
              </Link>
              <Link
                to="/pay-bill"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                পে বিল
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
