import Header from '../components/Header';
import Footer from '../components/Footer';
import { Copy, CheckCircle2, Smartphone, CreditCard, Wallet } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

const PayBill = () => {
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  const paymentMethods = [
    {
      name: "বিকাশ",
      number: "০১৭১২-৩৪৫৬৭৮",
      type: "Personal",
      icon: <Smartphone className="h-8 w-8" />,
      color: "bg-gradient-to-br from-pink-500 to-pink-600",
      textColor: "text-pink-600",
      bgLight: "bg-gradient-to-br from-pink-50 to-pink-100",
      borderColor: "border-pink-200"
    },
    {
      name: "নগদ",
      number: "০১৮৯৮-৭৬৫৪ৣ২",
      type: "Personal", 
      icon: <CreditCard className="h-8 w-8" />,
      color: "bg-gradient-to-br from-orange-500 to-orange-600",
      textColor: "text-orange-600",
      bgLight: "bg-gradient-to-br from-orange-50 to-orange-100",
      borderColor: "border-orange-200"
    },
    {
      name: "রকেট",
      number: "০১৬৫৫-৯৮৭৬৫৪",
      type: "Personal",
      icon: <Wallet className="h-8 w-8" />,
      color: "bg-gradient-to-br from-purple-500 to-purple-600",
      textColor: "text-purple-600",
      bgLight: "bg-gradient-to-br from-purple-50 to-purple-100",
      borderColor: "border-purple-200"
    }
  ];

  const copyToClipboard = (number: string, method: string) => {
    navigator.clipboard.writeText(number).then(() => {
      setCopiedNumber(method);
      setTimeout(() => setCopiedNumber(null), 2000);
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-sky-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 via-blue-700 to-sky-400 py-24 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-10 left-10 w-20 h-20 bg-white opacity-10 rounded-full animate-pulse"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-yellow-300 opacity-20 rounded-full animate-bounce"></div>
          <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-300 opacity-15 rounded-full animate-pulse"></div>
        </div>
        <div className="relative container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-8 animate-fade-in">
              পে বিল
            </h1>
            <p className="text-2xl text-blue-100 max-w-3xl mx-auto leading-relaxed animate-fade-in">
              সহজ ও নিরাপদ পেমেন্টের জন্য আপনার পছন্দের মোবাইল ব্যাংকিং ব্যবহার করুন
            </p>
            <div className="mt-8 flex justify-center">
              <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-full px-8 py-3">
                <p className="text-white font-medium">৩টি সহজ পেমেন্ট অপশন</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Methods */}
      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 animate-fade-in">
              পেমেন্ট মেথড
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              নিচের যেকোনো নম্বরে আপনার বিল পাঠাতে পারেন। সব নম্বরই পার্সোনাল অ্যাকাউন্ট।
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-6xl mx-auto">
            {paymentMethods.map((method, index) => (
              <div
                key={index}
                className={`${method.bgLight} ${method.borderColor} border-2 rounded-3xl p-8 text-center hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-fade-in`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className={`w-20 h-20 ${method.color} rounded-2xl flex items-center justify-center text-white mx-auto mb-8 shadow-lg`}>
                  {method.icon}
                </div>
                
                <h3 className={`text-3xl font-bold ${method.textColor} mb-4`}>
                  {method.name}
                </h3>
                
                <div className="bg-white p-6 rounded-2xl border-2 border-dashed border-gray-300 mb-6 shadow-inner">
                  <p className="text-sm text-gray-500 mb-3 font-medium">অ্যাকাউন্ট নম্বর</p>
                  <p className="text-2xl font-mono font-bold text-gray-800 mb-4 tracking-wider">
                    {method.number}
                  </p>
                  <p className="text-sm text-gray-500 mb-6 bg-gray-50 px-4 py-2 rounded-lg">
                    ({method.type} Account)
                  </p>
                  
                  <Button
                    onClick={() => copyToClipboard(method.number, method.name)}
                    className={`${method.color} hover:opacity-90 text-white w-full py-3 text-lg font-medium shadow-lg transition-all duration-300 transform hover:scale-105`}
                  >
                    {copiedNumber === method.name ? (
                      <>
                        <CheckCircle2 className="h-5 w-5 mr-3" />
                        কপি হয়েছে!
                      </>
                    ) : (
                      <>
                        <Copy className="h-5 w-5 mr-3" />
                        নম্বর কপি করুন
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Payment Instructions */}
      <section className="bg-white py-24 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-20 left-20 w-40 h-40 bg-blue-500 rounded-full"></div>
          <div className="absolute bottom-20 right-20 w-32 h-32 bg-green-500 rounded-full"></div>
        </div>
        <div className="relative container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 text-center mb-16">
              পেমেন্ট করার নিয়ম
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {/* Bkash Instructions */}
              <div className="bg-gradient-to-br from-pink-50 to-pink-100 p-8 rounded-3xl border-l-8 border-pink-500 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-2xl font-bold text-pink-600 mb-6 flex items-center">
                  <Smartphone className="h-6 w-6 mr-3" />
                  বিকাশ পেমেন্ট
                </h3>
                <ol className="space-y-4 text-gray-700 text-lg">
                  <li className="flex items-start">
                    <span className="bg-pink-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">১</span>
                    বিকাশ অ্যাপ বা *২৪৭# ডায়াল করুন
                  </li>
                  <li className="flex items-start">
                    <span className="bg-pink-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">২</span>
                    "Send Money" অপশন বেছে নিন
                  </li>
                  <li className="flex items-start">
                    <span className="bg-pink-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">৩</span>
                    নম্বর: ০১৭১২-৩৪৫৬৭৮
                  </li>
                  <li className="flex items-start">
                    <span className="bg-pink-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">৪</span>
                    পরিমাণ ও পিন দিয়ে পাঠান
                  </li>
                </ol>
              </div>

              {/* Nagad Instructions */}
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-8 rounded-3xl border-l-8 border-orange-500 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-2xl font-bold text-orange-600 mb-6 flex items-center">
                  <CreditCard className="h-6 w-6 mr-3" />
                  নগদ পেমেন্ট
                </h3>
                <ol className="space-y-4 text-gray-700 text-lg">
                  <li className="flex items-start">
                    <span className="bg-orange-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">১</span>
                    নগদ অ্যাপ বা *১৬৭# ডায়াল করুন
                  </li>
                  <li className="flex items-start">
                    <span className="bg-orange-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">২</span>
                    "Send Money" সিলেক্ট করুন
                  </li>
                  <li className="flex items-start">
                    <span className="bg-orange-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">৩</span>
                    নম্বর: ০১৮৯৮-৭৬৫৪৩২
                  </li>
                  <li className="flex items-start">
                    <span className="bg-orange-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">৪</span>
                    টাকার পরিমাণ ও পিন দিন
                  </li>
                </ol>
              </div>

              {/* Rocket Instructions */}
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-3xl border-l-8 border-purple-500 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-2xl font-bold text-purple-600 mb-6 flex items-center">
                  <Wallet className="h-6 w-6 mr-3" />
                  রকেট পেমেন্ট
                </h3>
                <ol className="space-y-4 text-gray-700 text-lg">
                  <li className="flex items-start">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">১</span>
                    রকেট অ্যাপ বা *৩২২# ডায়াল করুন
                  </li>
                  <li className="flex items-start">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">২</span>
                    "Send Money" অপশন চুন
                  </li>
                  <li className="flex items-start">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">৩</span>
                    নম্বর: ০১৬৫৫-৯৮৭৬৫৪
                  </li>
                  <li className="flex items-start">
                    <span className="bg-purple-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">৪</span>
                    পরিমাণ ও পিন দিয়ে পাঠান
                  </li>
                </ol>
              </div>

              {/* General Instructions */}
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-3xl border-l-8 border-blue-500 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-2xl font-bold text-blue-600 mb-6">গুরুত্বপূর্ণ তথ্য</h3>
                <ul className="space-y-4 text-gray-700 text-lg">
                  <li className="flex items-start">
                    <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">•</span>
                    পেমেন্ট করার পর Transaction ID সংরক্ষণ করুন
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">•</span>
                    SMS বা কল করে TrxID জানান
                  </li>
                  <li className="flex items-start">
                    <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1">•</span>
                    ২৪ ঘন্টার মধ্যে কানেকশন চালু হবে
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default PayBill;
