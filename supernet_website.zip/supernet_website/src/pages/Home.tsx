import { useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Wifi, Shield, Clock, Users } from 'lucide-react';

const Home = () => {
  useEffect(() => {
    // Smooth scroll animation for elements
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
        }
      });
    }, observerOptions);

    const elements = document.querySelectorAll('.fade-in-element');
    elements.forEach(el => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-sky-50">
      <Header />
      
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center space-y-8 fade-in-element">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-800 leading-tight">
            Supernet Online Service
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto">
            সহজ সংযোগ, নিরবিচারে ভালোবাসা।
          </p>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto">
            আমরা আপনাকে সর্বোচ্চ মানের ইন্টারনেট সেবা প্রদান করি যা নির্ভরযোগ্য, দ্রুত এবং সাশ্রয়ী।
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/price">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg">
                প্যাকেজ দেখুন
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-3 text-lg">
                যোগাযোগ করুন
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 fade-in-element">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              কেন আমাদের বেছে নেবেন?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              আমাদের রয়েছে অভিজ্ঞ টিম এবং আধুনিক প্রযুক্তি যা আপনাকে সেরা সেবা দিতে প্রতিশ্রুতিবদ্ধ।
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors fade-in-element">
              <Wifi className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">দ্রুত গতি</h3>
              <p className="text-gray-600">উচ্চ গতির ইন্টারনেট সংযোগ যা আপনার সব প্রয়োজন মেটাবে।</p>
            </div>

            <div className="text-center p-6 rounded-lg bg-green-50 hover:bg-green-100 transition-colors fade-in-element">
              <Shield className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">নিরাপত্তা</h3>
              <p className="text-gray-600">আপনার ডেটা এবং গোপনীয়তা সুরক্ষিত রাখতে আমরা প্রতিশ্রুতিবদ্ধ।</p>
            </div>

            <div className="text-center p-6 rounded-lg bg-yellow-50 hover:bg-yellow-100 transition-colors fade-in-element">
              <Clock className="h-12 w-12 text-yellow-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">২৪/৭ সাপোর্ট</h3>
              <p className="text-gray-600">যেকোনো সমস্যায় আমরা আছি আপনার পাশে, দিন-রাত।</p>
            </div>

            <div className="text-center p-6 rounded-lg bg-purple-50 hover:bg-purple-100 transition-colors fade-in-element">
              <Users className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">বিশ্বস্ত সেবা</h3>
              <p className="text-gray-600">হাজারো সন্তুষ্ট গ্রাহকের বিশ্বাস অর্জন করেছি আমরা।</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-sky-400 py-20">
        <div className="container mx-auto px-4 text-center fade-in-element">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            আজই শুরু করুন আপনার ইন্টারনেট যাত্রা
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            আমাদের সাথে যোগ দিন এবং উপভোগ করুন অসাধারণ ইন্টারনেট অভিজ্ঞতা।
          </p>
          <Link to="/contact">
            <Button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 text-lg font-medium">
              এখনই যোগাযোগ করুন
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;
